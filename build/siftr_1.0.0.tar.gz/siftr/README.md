<img src="https://cdn.rawgit.com/omarwagih/rmimp/master/inst/extdata/html/images/mimp_logo.svg" alt="rmimp logo" width="250px"><br> Predicting the impact of mutations on protein function
===============================================================

## Installation

To install siftr, first make sure your R version is at least R 3.0. You can check by typing the following into your R console:

```r
R.Version()$major
```

Install and load `devtools` package:

```r
install.packages("devtools")
library("devtools")
```

Download and install the `siftr` package from github:

```r
install_github("omarwagih/siftr")
```

Load the `siftr` package

```r
library("siftr")
```

## Running siftr on sample data:

```r
# Create a dummy alignment
mut.file = system.file("extdata", "mutation_data.txt", package = "rmimp")


## Contact
If you have any feedback, suggestions or questions, please drop me a line at (wagih(at)ebi.ac.uk) or open an issue on github.